function verificar_email() {
     return email.value.indexOf("@") > -1 && email.value.endsWith(".com") || email.value.indexOf("@") > -1 && email.value.endsWith(".com.br");
     
   }

function verificar_senha() {
     return senha.value.length >= 8 && senha.value.length <= 12;
}

function confirmar_senha() {
    console.log(senha.value == confirmarSenha.value);
    return senha.value == confirmarSenha.value;
}

function campo_vazio() {
    return email.value == "" || senha.value == "" || confirmar_senha.value == "";
}

function botao_cadastrar() {

    if(campo_vazio()) {
        alert("campo vazio");
    }

   else if(!verificar_email()) { 
        alert("email inválido");
        
    }

    else if(!confirmar_senha()) {
        alert("Senha Inconmpativel");
    }

    else if(!verificar_senha()) {
        alert("a senha deve conter no minimo 8 ou maximo 12 caracteres");
    }


    else {
        cadastrar();
    }
} 

    function cadastrar() {
        var formulario = new URLSearchParams(new FormData(form_cadastro));
        fetch("/usuarios/cadastrar", {
            method: "POST",
            body: formulario
        }).then(function (response) {
            
            if (response.ok) {

                window.location.href='login.html';

            } else {

                console.log('Erro de cadastro!');
                alert("erro de cadastro");
            }
        });

        return false;
    }


 

