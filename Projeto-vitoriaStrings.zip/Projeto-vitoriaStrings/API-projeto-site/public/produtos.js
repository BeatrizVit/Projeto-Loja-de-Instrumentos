function buscar_produto() {
    var produto_selecionado = busque_produtos.value;

    /*<img src="./imgSite/produtoViolaArcoLaminada.jpeg">*/

    if(produto_selecionado.toLowerCase().indexOf("instrumentos") > -1 || produto_selecionado.toLowerCase().indexOf("instrumento") > -1) {
       resultado_buscar.innerHTML = ` <div class="box">
                                        <div class="containerProd">
                                            <div class="produtos">
                                                <img src="./imgSite/produtoViolaArcoLaminada.jpeg">
                                                <h3>Viola De Arco Laminada Orquezz 3/4 <br><br><br> R$614,65</h3>
                                                <a href="">Adicionar ao carrinho</a><br><br>
                                                <a href=compra.html">Comprar</a> 
                                            </div>

                                            <div class="produtos">
                                                <img src="./imgSite/Guitarra Stratocaster Giannini G100 3TS WH Sunburst01.jpg" alt="">
                                                <h3>Guitarra Stratocaster Giannini G100 <br>3TS/WH Sunburst <br><br> R$634,50</h3>
                                                <a href="">Adicionar ao carrinho</a><br><br>
                                                <a href=compra.html">Comprar</a> 
                                            </div>

                                            <div class="produtos">
                                                <img src="./imgSite/VIOLAO GIANNINI START N-14 BK NYLON ACUSTICO PRETO01.jpg" alt="">
                                                <h3>Violão GIANNINI START N-14 BK Nylon Acustico preto <br><br> R$501,30</h3>
                                                <a href="">Adicionar ao carrinho</a><br><br>
                                                <a href=compra.html">Comprar</a> 
                                            </div>

                                            <div class="produtos">
                                                <img src="./imgSite/Violão Elétrico Mini Jumbo Strinberg SA200C MGS Mogno Fosco01.jpg" alt="">
                                                <h3>Violão Elétrico Mini Jumbo Strinberg SA200C MGS Mogno Fosco<br><br> R$772,08</h3>
                                                <a href="">Adicionar ao carrinho</a><br><br>
                                                <a href=compra.html">Comprar</a> 
                                            </div>

                                            <div class="produtos">
                                                <img src="./imgSite/Violino Vignoli VIG 644 NA Profissional 4barra4 Fosco Tampo Spruce sólido01.jpg" alt="">
                                                <h3>Violino Vignoli VIG 644 NA Profissional 4/4 Fosco Tampo Spruce sólido <br><br> R$1.324,56</h3>
                                                <a href="">Adicionar ao carrinho</a><br><br>
                                                <a href=compra.html">Comprar</a> 
                                            </div>

                                            <div class="produtos">
                                                <img src="./imgSite/guitarra les Paul.jpg" alt="">
                                                <h3>Guitarra Strinberg Les Paul Lps 230 Preta <br> <br> <br> R$ 1,200,00</h3>
                                                <a href="">Adicionar ao carrinho</a><br><br>
                                                <a href=compra.html">Comprar</a> 
                                            </div>
                                        </div>
                                    </div>`;
    } 

    else if(produto_selecionado.toLowerCase().indexOf("cordas") > -1 || produto_selecionado.toLowerCase().indexOf("corda") > -1) {
        resultado_buscar.innerHTML = `<div class="box">
                                        <div class="containerProd">
                                            <div class="produtos">
                                                <img src="./imgSite/cordaDaddario01.jpg" alt="">
                                                <h3>Giannini Encordoamento Violão Aço Bronze <br> 85/15 0.010 GEEFLE <br> <br> R$ 22,00</h3>
                                                <a href="">Adicionar ao carrinho</a><br><br>
                                                <a href=compra.html">Comprar</a> 
                                            </div>

                                            <div class="produtos">
                                                <img src="./imgSite/corda guitarra 0.10 01.jpg" alt="">
                                                <h3>Encordoamento para Guitarra aço 6 cordas Nig 010/046 n-64 <br> <br> R$ 35,00</h3>
                                                <a href="">Adicionar ao carrinho</a><br><br>
                                                <a href=compra.html">Comprar</a> 
                                            </div>

                                             <div class="produtos">
                                                <img src="./imgSite/corda nylon violão canario01.jpg" alt="">
                                                <h3>Jogo De Cordas Para Violão Nylon Tensão Média Canário GENWB<br> <br> R$21,90</h3>
                                                <a href="">Adicionar ao carrinho</a><br><br>
                                                <a href=compra.html">Comprar</a> 
                                            </div>

                                            <div class="produtos">
                                                <img src="./imgSite/corda para viola paganini01.jpg" alt="">
                                                <h3>Encordoamento Cordas Paganini Pe970 Para Viola De Arco<br> <br> R$ 30,00</h3>
                                                <a href="">Adicionar ao carrinho</a><br><br>
                                                <a href=compra.html">Comprar</a> 
                                            </div>

                                            <div class="produtos">
                                                <img src="./imgSite/corda violão aço gianini01.jpeg" alt="">
                                                <h3>Jogo De Cordas Violão Aço 009 Giannini 65/35 - Premium<br> <br> R$25,00</h3>
                                                <a href="">Adicionar ao carrinho</a><br><br>
                                                <a href=compra.html">Comprar</a> 
                                            </div>

                                            <div class="produtos">
                                                <img src="./imgSite/corda para violino paganini01.jpg" alt="">
                                                <h3>Paganini Jogo De Corda Violino C/ Perlon Pe980 Profissional<br> <br> R$45,90</h3>
                                                <a href="">Adicionar ao carrinho</a><br><br>
                                                <a href=compra.html">Comprar</a> 
                                            </div>
                                        </div>
                                    </div>`;
    }

    else if(produto_selecionado.toLowerCase().indexOf("capa") > -1 || produto_selecionado.toLowerCase().indexOf("case") > -1) {
        resultado_buscar.innerHTML = `<div class="box">
                                        <div class="containerProd">
                                            <div class="produtos">
                                                <img src="./imgSite/violino case 4 barra 4 01.jpg" alt="">
                                                <h3>Estojo violino 4/4 GOTA <br> <br> <br>R$ 105,00</h3>
                                                <a href="">Adicionar ao carrinho</a><br><br>
                                                <a href=compra.html">Comprar</a> 
                                            </div>

                                            <div class="produtos">
                                                <img src="./imgSite/case viola 01.jpg" alt="">
                                                <h3>Estojo Case Para Viola Caipira Rozini - Kromu <br> <br> R$ 469,00</h3>
                                                <a href="">Adicionar ao carrinho</a><br><br>
                                                <a href="compra.html">Comprar</a> 
                                            </div>

                                            <div class="produtos">
                                                <img src="./imgSite/case guitarra Les Paul 01.jpg" alt="">
                                                <h3>Hard Case Guitarra Les Paul Marrom Luxo - Vogga <br> <br> R$ 533,84</h3>
                                                <a href="">Adicionar ao carrinho</a><br><br>
                                                <a href=compra.html">Comprar</a> 
                                            </div>

                                            <div class="produtos">
                                                <img src="./imgSite/case violão 01.jpg" alt="">
                                                <h3>Case para Violao Dread Folk em Madeira - GW-DREAD - GATOR<br> <br> R$ 862,00</h3>
                                                <a href="">Adicionar ao carrinho</a><br><br>
                                                <a href=compra.html">Comprar</a> 
                                            </div>

                                            <div class="produtos">
                                                <img src="./imgSite/case cello 01.jpg" alt="">
                                                <h3>Estojo Case Violoncelo 4/4 Leilo Trançado<br> <br> <br> R$1.199,00</h3>
                                                <a href="">Adicionar ao carrinho</a><br><br>
                                                <a href=compra.html">Comprar</a> 
                                            </div>
                                        </div>
                                    </div>`;
    }

    else if(produto_selecionado.toLowerCase().indexOf("palhetas") > -1 || produto_selecionado.toLowerCase().indexOf("palheta") > -1) {
        resultado_buscar.innerHTML = `<div class="box">
                                        <div class="containerProd">
                                            <div class="produtos">
                                                <img src="./imgSite/palheta preta USA 01.jpg" alt="">
                                                <h3>Palheta Planet Waves Para Guitarra Violão Baixo Heavy Grossa Preta 1.2 <br> <br> R$4,50</h3>
                                                <a href="">Adicionar ao carrinho</a><br><br>
                                                <a href=compra.html">Comprar</a> 
                                            </div>
                                
                                            <div class="produtos">
                                                <img src="./imgSite/palheta verde 01.png" alt="">
                                                <h3>Palheta Dunlop Tortex .88 mm<br> <br> <br>  R$ 2,50</h3>
                                                <a href="">Adicionar ao carrinho</a><br><br>
                                                <a href=compra.html">Comprar</a> 
                                            </div>

                                            <div class="produtos">
                                                <img src="./imgSite/palheta laranja.jpg" alt="">
                                                <h3>Dunlop Nylon Midi Pick 0.67mm Laranja 443r67 <br> <br> R$ 2,00</h3>
                                                <a href="">Adicionar ao carrinho</a><br><br>
                                                <a href=compra.html">Comprar</a> 
                                            </div>
                                        </div>
                                    </div>`;
    } 
    
    else {
        resultado_buscar.innerHTML = `<span style="font-size: 190%"><b> Categoria Não Encontrada :( </b><span>`;
    }
}

